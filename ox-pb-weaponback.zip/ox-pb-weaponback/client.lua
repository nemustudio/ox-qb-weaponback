local QBCore = exports['qb-core']:GetCoreObject()

local CurrentBackItems = {}
local TempBackItems = {}
local checking = true
local currentWeapon = nil
local itemsCache = {}

local SLOT_MIN = 1
local SLOT_MAX = 5

AddEventHandler('onResourceStart', function(resourceName)
    if (GetCurrentResourceName() ~= resourceName) then return end
    BackLoop()
end)

AddEventHandler('onResourceStop', function(resourceName)
    if (GetCurrentResourceName() ~= resourceName) then return end
    resetItems()
end)

RegisterNetEvent("QBCore:Client:OnPlayerUnload", function()
    resetItems()
end)

RegisterNetEvent("clause-backitems:start", function()
    Wait(10000)
    BackLoop()
end)

RegisterNetEvent("clause-backitems:displayItems", function(toggle)
    if toggle then
        for k, v in pairs(TempBackItems) do
            createBackItem(k)
        end
        BackLoop()
    else
        TempBackItems = CurrentBackItems
        checking = false
        for k, v in pairs(CurrentBackItems) do
            removeBackItem(k)
        end
        CurrentBackItems = {}
    end
end)

function resetItems()
    removeAllBackItems()
    CurrentBackItems = {}
    TempBackItems = {}
    currentWeapon = nil
    itemsCache = {}
    checking = false
end

local function getOxItems()
    if GetResourceState('ox_inventory') ~= 'started' then
        return nil
    end
    return exports.ox_inventory:GetPlayerItems()
end

local function inSlotRange(item)

    if not item or item.slot == nil then return false end
    return item.slot >= SLOT_MIN and item.slot <= SLOT_MAX
end

function BackLoop()
    print(("[Backitems]: Starting Loop (ox_inventory mode) slots %d-%d"):format(SLOT_MIN, SLOT_MAX))
    checking = true

    CreateThread(function()
        while checking do
            local items = getOxItems()
            if items then
                itemsCache = items
                check()
            else
                print("[Backitems]: ox_inventory not started or GetPlayerItems failed")
            end
            Wait(1000)
        end
    end)
end

function check()

    for _, item in pairs(itemsCache) do
        if item and item.name and inSlotRange(item) then
            local key = string.upper(item.name)
            if BackItems[key] then
                if key ~= currentWeapon then
                    createBackItem(key)
                end
            end
        end
    end

    for backKey, obj in pairs(CurrentBackItems) do
        local keep = false

        if backKey == currentWeapon then
            keep = false
        else
            for _, item in pairs(itemsCache) do
                if item and item.name then
                    local key = string.upper(item.name)
                    if key == backKey and inSlotRange(item) then
                        keep = true
                        break
                    end
                end
            end
        end

        if not keep then
            removeBackItem(backKey)
        end
    end
end

function createBackItem(item)
    item = string.upper(item)

    if CurrentBackItems[item] then return end
    if not BackItems[item] then return end

    local i = BackItems[item]
    local modelHash = joaat(i.model)

    local ped = PlayerPedId()
    local bone = GetPedBoneIndex(ped, i.back_bone)

    RequestModel(modelHash)
    while not HasModelLoaded(modelHash) do
        Wait(10)
    end
    SetModelAsNoLongerNeeded(modelHash)

    CurrentBackItems[item] = CreateObject(modelHash, 1.0, 1.0, 1.0, true, true, false)

    local y = i.y
    local pd = QBCore.Functions.GetPlayerData()
    if pd and pd.charinfo and pd.charinfo.gender == 1 then
        y = y + 0.035
    end

    AttachEntityToEntity(
        CurrentBackItems[item],
        ped,
        bone,
        i.x, y, i.z,
        i.x_rotation, i.y_rotation, i.z_rotation,
        0, 1, 0, 1, 0, 1
    )
end

function removeBackItem(item)
    item = string.upper(item)
    if CurrentBackItems[item] then
        DeleteEntity(CurrentBackItems[item])
        CurrentBackItems[item] = nil
    end
end

function removeAllBackItems()
    for k, v in pairs(CurrentBackItems) do
        removeBackItem(k)
    end
end

RegisterNetEvent('weapons:client:SetCurrentWeapon', function(weap, shootbool)
    if weap == nil then

        currentWeapon = nil
    else
        currentWeapon = string.upper(tostring(weap.name))
        removeBackItem(currentWeapon)
    end
end)
