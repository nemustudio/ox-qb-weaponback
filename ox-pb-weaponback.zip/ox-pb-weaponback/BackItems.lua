BackItems = {

    ["WEAPON_SR_3M_VVS"] = {
    model = "did_sr_3m_vvs",
    back_bone = 24818,
    x = 0.02,
    y = -0.18,
    z = -0.10,
    x_rotation = 0.0,
    y_rotation = -180.0,
    z_rotation = 180.0,
    },


    ["WEAPON_SMG"] = {
        model = "w_sb_smg",
        back_bone = 24818,
        x = 0.0,
        y = -0.17,
        z = -0.12,
        x_rotation = 0.0,
        y_rotation = -180.0,
        z_rotation = 180.0,
    },

    ["WEAPON_PUMPSHOTGUN"] = {
        model = "w_sg_pumpshotgun",
        back_bone = 24818,
        x = 0.0,
        y = -0.17,
        z = -0.12,
        x_rotation = 0.0,
        y_rotation = -180.0,
        z_rotation = 180.0,
    },

    ["WEAPON_SAWNOFFSHOTGUN"] = {
        model = "w_sg_sawnoff",
        back_bone = 24818,
        x = 0.0,
        y = -0.17,
        z = -0.12,
        x_rotation = 0.0,
        y_rotation = -180.0,
        z_rotation = 180.0,
    },

    ["WEAPON_MICROSMG"] = {
        model = "w_sb_microsmg",
        back_bone = 24818,
        x = 0.05,
        y = -0.16,
        z = -0.10,
        x_rotation = 0.0,
        y_rotation = -180.0,
        z_rotation = 160.0,
    },

    ["WEAPON_ASSAULTSMG"] = {
        model = "w_sb_assaultsmg",
        back_bone = 24818,
        x = 0.02,
        y = -0.17,
        z = -0.12,
        x_rotation = 0.0,
        y_rotation = -180.0,
        z_rotation = 180.0,
    },

    ["WEAPON_HEAVYSNIPER"] = {
        model = "w_sr_heavysniper",
        back_bone = 24818,
        x = 0.12,
        y = -0.20,
        z = -0.05,
        x_rotation = 0.0,
        y_rotation = -180.0,
        z_rotation = 180.0,
    },

    ["WEAPON_MUSKET"] = {
        model = "w_ar_musket",
        back_bone = 24818,
        x = 0.12,
        y = -0.20,
        z = -0.05,
        x_rotation = 0.0,
        y_rotation = -180.0,
        z_rotation = 180.0,
    },

    ["WEAPON_ASSAULTRIFLE"] = {
        model = "w_ar_assaultrifle",
        back_bone = 24818,
        x = 0.0,
        y = -0.18,
        z = -0.06,
        x_rotation = 0.0,
        y_rotation = -180.0,
        z_rotation = 180.0,
    },

    ["WEAPON_CARBINERIFLE"] = {
        model = "w_ar_carbinerifle",
        back_bone = 24818,
        x = 0.0,
        y = -0.18,
        z = -0.04,
        x_rotation = 0.0,
        y_rotation = -180.0,
        z_rotation = 180.0,
    },

    ["WEAPON_SPECIALCARBINE"] = {
        model = "w_ar_specialcarbine",
        back_bone = 24818,
        x = 0.0,
        y = -0.18,
        z = -0.06,
        x_rotation = 0.0,
        y_rotation = -180.0,
        z_rotation = 180.0,
    },

    ["WEAPON_BAT"] = {
        model = "w_me_bat",
        back_bone = 24818,
        x = 0.20,
        y = -0.16,
        z = -0.18,
        x_rotation = 270.0,
        y_rotation = 90.0,
        z_rotation = 180.0,
    },

    ["WEAPON_GOLFCLUB"] = {
        model = "w_me_gclub",
        back_bone = 24818,
        x = 0.22,
        y = -0.16,
        z = -0.12,
        x_rotation = 270.0,
        y_rotation = 90.0,
        z_rotation = 180.0,
    },

    ["WEAPON_RPG"] = {
        model = "w_lr_rpg",
        back_bone = 24818,
        x = 0.10,
        y = -0.22,
        z = -0.05,
        x_rotation = 0.0,
        y_rotation = 180.0,
        z_rotation = 180.0,
    },

    ["WEED_BRICK"] = {
        model = "bkr_prop_weed_drying_01a",
        back_bone = 24818,
        x = -0.18,
        y = -0.18,
        z = -0.05,
        x_rotation = 0.0,
        y_rotation = 90.0,
        z_rotation = 0.0,
    },

}
