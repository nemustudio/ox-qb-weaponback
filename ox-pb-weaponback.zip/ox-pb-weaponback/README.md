# Weapons-On-Back-Script-QBCore
A script that displays any type of big guns in the inventory of players

dependencies
'ox_inventory'

For support dm - jin_xd on discord

#How to install
- download then open the winzip or folder.
- Then place the folder into a sub folder inside your resources. you may change the folders name to your liking!
