fx_version 'cerulean'
games { 'gta5' }

author 'Nemu Studio LLC.'

client_scripts {
    'client.lua',
    'BackItems.lua',
}
